# 📊 Projet 12 — Détection automatique de faux billets
## Synthèse pour la soutenance

---

## 🎯 Contexte et objectifs

**Organisation** : ONCFM (Organisation nationale de lutte contre le faux-monnayage)

**Problématique** : Développer un algorithme capable de différencier automatiquement les vrais des faux billets à partir de leurs caractéristiques géométriques mesurées par une machine.

**Données** :
- 1 500 billets (1 000 vrais, 500 faux)
- 6 caractéristiques géométriques (en mm)
- 37 valeurs manquantes (2.47%) sur la variable `margin_low`

---

## 📈 Méthodologie

### 1. Exploration et nettoyage des données
- **Analyse descriptive** : distributions, boxplots, scatter plots, matrice de corrélation
- **Imputation** : médiane par groupe (is_genuine) pour préserver les distributions
- **Variables clés identifiées** : `margin_low` et `length` (forte séparation visuelle)

### 2. Préparation des données
- **Split** : 70% train (1 050) / 30% test (450)
- **Stratification** : maintien de la proportion vrais/faux
- **Standardisation** : pour les modèles sensibles à l'échelle (LR, KNN, K-Means)

### 3. Modélisation (4 algorithmes testés)

#### Apprentissage supervisé
1. **Régression Logistique** ⭐
   - Accuracy : **99.33%**
   - FP : 1 | FN : 2
   - F1-Score (Faux) : 0.99
   
2. **K-Nearest Neighbors (k=5)**
   - Accuracy : 98.67%
   - FP : 2 | FN : 4
   - F1-Score (Faux) : 0.98

3. **Random Forest (100 arbres)**
   - Accuracy : 98.67%
   - FP : 3 | FN : 3
   - F1-Score (Faux) : 0.98
   - **Bonus** : Feature importance

#### Apprentissage non supervisé
4. **K-Means (k=2)**
   - Accuracy : 98.44%
   - FP : 3 | FN : 4
   - Confirme la structure naturelle des données

---

## ✅ Résultats et choix du modèle

### Modèle retenu : Régression Logistique

**Justification** :
1. **Meilleure performance** : 99.33% d'accuracy (seulement 3 erreurs sur 450)
2. **Équilibre FP/FN optimal** : 1 FP et 2 FN (vs 4 FN pour KNN)
3. **Probabilités fiables** : scores très polarisés (proches de 0 ou 1)
4. **Rapidité** : entraînement et prédiction très rapides
5. **Interprétabilité** : coefficients explicables pour l'ONCFM

### Variables les plus importantes
D'après le Random Forest :
1. **margin_low** : 38.2%
2. **length** : 31.6%
3. **margin_up** : 14.3%
4. **height_left** : 8.1%

→ Les 2 premières variables représentent ~70% du pouvoir discriminant

---

## 🚀 Application déployable

### Script Python (`script_detection_faux_billets.py`)

**2 modes d'utilisation** :

1. **Mode fichier CSV** : `python script.py --fichier billets.csv`
   - Analyse batch de plusieurs billets
   - Sauvegarde automatique des résultats

2. **Mode manuel** : `python script.py --manuel`
   - Saisie interactive des dimensions
   - Résultat immédiat avec confiance

**Fonctionnalités** :
- Entraînement automatique du modèle à chaque lancement
- Gestion des valeurs manquantes
- Output avec prédiction + niveau de confiance (%)
- Fichier CSV de sortie avec tous les résultats

---

## 📊 Métriques clés

| Métrique | Valeur |
|----------|--------|
| **Accuracy globale** | 99.33% |
| **Precision (Faux)** | 99.33% |
| **Recall (Faux)** | 98.67% |
| **F1-Score (Faux)** | 99.00% |
| **Faux positifs** | 1/450 (0.22%) |
| **Faux négatifs** | 2/450 (0.44%) |

---

## 💡 Points clés pour la soutenance

1. **Problème métier bien compris** : Les faux négatifs sont plus critiques (faux billet non détecté = échec sécurité) → la régression logistique minimise ce risque

2. **Approche méthodique** :
   - EDA approfondie avant modélisation
   - Imputation justifiée par groupe
   - 4 modèles testés pour comparaison
   - Validation sur apprentissage non supervisé

3. **Résultats exceptionnels** : 99.33% d'accuracy avec seulement 3 erreurs sur 450 billets

4. **Production-ready** : Script déployable avec 2 modes d'utilisation

5. **Interprétabilité** : Importance des variables documentée (margin_low + length = 70%)

---

## 📦 Livrables

1. **Notebook Jupyter** : Pipeline complet avec visualisations
2. **Script Python** : Application de détection prête à l'emploi
3. **Présentation PowerPoint** : 18 slides (20 max requis)
4. **Fichiers de support** :
   - README d'utilisation du script
   - Dataset original (billets.csv)
   - Exemple de fichier test

---

## 🎓 Compétences démontrées

✅ **Utiliser un modèle d'apprentissage supervisé**
- Imputation des valeurs manquantes (médiane par groupe)
- Séparation train/test stratifiée
- Prédiction avec probabilités
- Interprétation des métriques (accuracy, precision, recall, F1, confusion matrix)
- Justification du choix des variables

✅ **Entraîner un modèle non supervisé**
- K-Means avec k=2
- Caractérisation des clusters
- Évaluation de la forme (visualisation PCA)
- Justification de la méthodologie

---

## 🔍 Pistes d'amélioration futures

1. **Optimisation hyperparamètres** : GridSearchCV sur tous les modèles
2. **Feature engineering** : ratios entre dimensions, polynômes
3. **Ensemble methods** : Voting classifier combinant les 3 meilleurs
4. **Interface web** : Déploiement Flask/Streamlit pour l'ONCFM
5. **Monitoring** : Suivi de la performance en production

---

**Bonne soutenance ! 🎓**
